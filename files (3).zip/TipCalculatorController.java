import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class TipCalculatorController {

    @FXML private TextField billAmountField;
    @FXML private TextField tipPercentageField;
    @FXML private Label tipAmountLabel;
    @FXML private Label errorLabel;

    @FXML
    private void calculateTip() {
        try {
            double bill = Double.parseDouble(billAmountField.getText().trim());
            double percentage = Double.parseDouble(tipPercentageField.getText().trim());

            if (bill < 0 || percentage < 0) {
                tipAmountLabel.setText("");
                errorLabel.setText("Error: Values cannot be negative.");
                return;
            }

            double tip = bill * percentage / 100.0;
            tipAmountLabel.setText(String.format("Tip Amount: $%.2f", tip));
            errorLabel.setText("");
        } catch (NumberFormatException e) {
            tipAmountLabel.setText("");
            errorLabel.setText("Error: Invalid input. Please enter numbers.");
        }
    }

    @FXML
    private void reset() {
        billAmountField.clear();
        tipPercentageField.clear();
        tipAmountLabel.setText("");
        errorLabel.setText("");
    }
}
